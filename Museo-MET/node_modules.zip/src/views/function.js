document.addEventListener('DOMContentLoaded', () => {
    const departmentSelect = document.getElementById('department');
    const searchForm = document.getElementById('searchForm');
    const resultsDiv = document.getElementById('results');

    // Cargar departamentos al iniciar
    fetch('https://collectionapi.metmuseum.org/public/collection/v1/departments')
        .then(response => response.json())
        .then(data => {
            data.departments.forEach(dept => {
                const option = document.createElement('option');
                option.value = dept.departmentId;
                option.textContent = dept.displayName;
                departmentSelect.appendChild(option);
            });
        })
        .catch(error => console.error('Error loading departments:', error));

    // Manejar la búsqueda
    searchForm.addEventListener('submit', (e) => {
        e.preventDefault();
        const departmentId = departmentSelect.value;
        const keyword = document.getElementById('keyword').value.trim();
        const geoLocation = document.getElementById('geoLocation').value.trim();

        // Validar que al menos un parámetro esté presente
        if (!departmentId && !keyword && !geoLocation) {
            alert("Ingrese al menos un parámetro de búsqueda.");
            return;
        }

        // Construir URL de búsqueda
        const searchParams = new URLSearchParams();
        if (departmentId) searchParams.append('departmentId', departmentId);
        if (keyword) searchParams.append('keyword', keyword);
        if (geoLocation) searchParams.append('geoLocation', geoLocation);

        fetch(`/api/search?${searchParams.toString()}`)
            .then(response => response.json())
            .then(data => {
                if (data.message) {
                    resultsDiv.innerHTML = `<p>${data.message}</p>`;
                    return;
                }
                displayResults(data.objectIDs.slice(0, 20)); // Limitar a 20 resultados
            })
            .catch(error => {
                console.error('Error:', error);
                resultsDiv.innerHTML = '<p>Error al buscar. Por favor, intenta de nuevo.</p>';
            });
    });

    function displayResults(objectIds) {
        resultsDiv.innerHTML = ''; // Limpiar resultados anteriores
        objectIds.forEach(id => {
            fetch(`https://collectionapi.metmuseum.org/public/collection/v1/objects/${id}`)
                .then(response => response.json())
                .then(object => {
                    const card = document.createElement('div');
                    card.className = 'card';
                    card.innerHTML = `
                        <img src="${object.primaryImageSmall || '/image/sinImagen.jpg'}" alt="${object.title}" class="img-small">
                        <h3>${object.title}</h3>
                        <a href="/object/${object.objectID}">Ver imágenes adicionales</a>
                    `;
                    resultsDiv.appendChild(card);
                })
                .catch(error => console.error('Error loading object:', error));
        });
    }
});