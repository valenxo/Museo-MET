import express from "express";
import path from "path";
import { fileURLToPath } from "url";
import axios from "axios";
import cors from "cors";

const app = express();
const PORT = 3000;
const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

// Habilita CORS
app.use(cors());
app.set("view engine", "pug");
app.set("views", path.join(__dirname, "views"));
app.use(express.static(path.join(__dirname, "views")));

// Ruta principal
app.get("/", (req, res) => {
    res.render("index");
});

// Ruta para buscar objetos (Proxy)
app.get("/api/search", async (req, res) => {
    const departmentId = req.query.departmentId || "";
    const keyword = req.query.keyword || "";
    const geoLocation = req.query.geoLocation || "";

    let url = `https://collectionapi.metmuseum.org/public/collection/v1/search?`;
    let hasParameter = false;

    if (departmentId) {
        url += `departmentId=${departmentId}`;
        hasParameter = true;
    }
    if (keyword) {
        url += `&q=${encodeURIComponent(keyword)}`; // Codificar la keyword
        hasParameter = true;
    }
    if (geoLocation) {
        url += `&geoLocation=${geoLocation}`;
        hasParameter = true;
    }

    // Verificar si se ingresó al menos un parámetro
    if (!hasParameter) {
        return res.status(400).json({ message: "Ingrese al menos un parámetro de búsqueda." });
    }

    try {
        const response = await axios.get(url);
        
        // Verifica si hay resultados
        if (response.data.total === 0) {
            return res.status(404).json({ message: "No se encontraron resultados para la búsqueda." });
        }

        // Enviar los datos de la API al cliente
        res.json(response.data);
    } catch (error) {
        console.error("Error fetching data from the API:", error.message);
        res.status(500).json({ message: "Error interno del servidor" });
    }
});

// Ruta para obtener detalles de un objeto
app.get("/object/:objectID", async (req, res) => {
    const objectID = req.params.objectID;

    try {
        const response = await axios.get(`https://collectionapi.metmuseum.org/public/collection/v1/objects/${objectID}`);
        res.render("object", { object: response.data });
    } catch (error) {
        console.error("Error fetching object details:", error.message);
        res.status(500).json({ message: "Error interno del servidor" });
    }
});

// Iniciar el servidor
app.listen(PORT, () => {
    console.log(`Servidor corriendo en el puerto ${PORT}`);
});